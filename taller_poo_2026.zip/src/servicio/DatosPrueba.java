package servicio;

import java.time.LocalDate;
import java.time.LocalDateTime;
import modelo.*;

/**
 * Carga un juego de datos de prueba en memoria para la defensa del taller. Las lecturas
 * se registran a través del sistema, por lo que se disparan alertas reales por umbrales.
 */
public final class DatosPrueba {
    private DatosPrueba() { }

    /**
     * Precarga zonas, personal, estaciones, sensores, mantenimientos, lecturas y alertas.
     *
     * @param s sistema a poblar
     */
    public static void cargar(SistemaMeteorologico s) {
        try {
            // Zonas (umbrales amarilla/naranja/roja en mm por 24 h)
            ZonaGeografica uruguay = s.registrarZona("Cuenca del Río Uruguay", NivelVulnerabilidad.ALTO, 40, 80, 120);
            ZonaGeografica gualeguay = s.registrarZona("Cuenca del Río Gualeguay", NivelVulnerabilidad.MEDIO, 50, 90, 150);
            ZonaGeografica delta = s.registrarZona("Delta del Paraná", NivelVulnerabilidad.MUY_ALTO, 35, 70, 110);
            double[] histUruguay = {130, 120, 130, 140, 90, 60, 50, 55, 90, 125, 140, 135};
            double[] histGualeguay = {110, 105, 120, 110, 75, 50, 40, 45, 70, 100, 115, 115};
            double[] histDelta = {120, 110, 125, 130, 85, 60, 55, 60, 85, 115, 120, 125};
            for (int m = 1; m <= 12; m++) {
                uruguay.setValorHistorico(m, histUruguay[m - 1]);
                gualeguay.setValorHistorico(m, histGualeguay[m - 1]);
                delta.setValorHistorico(m, histDelta[m - 1]);
            }

            // Personal técnico
            ResponsableTecnico r1 = s.registrarResponsable("30111222", "Lucía", "Fernández", "lfernandez@meteo.gob", "3454-111111", "Hidrología", "LIC-001");
            ResponsableTecnico r2 = s.registrarResponsable("28333444", "Martín", "Acosta", "macosta@meteo.gob", "3454-222222", "Instrumental", "LIC-002");
            ResponsableTecnico r3 = s.registrarResponsable("33555666", "Carolina", "Benítez", "cbenitez@meteo.gob", "3445-333333", "Meteorología", "LIC-003");
            ResponsableTecnico r4 = s.registrarResponsable("27777888", "Diego", "Sosa", "dsosa@meteo.gob", "3445-444444", "Emergencias", "LIC-004");
            ResponsableTecnico r5 = s.registrarResponsable("35999000", "Valeria", "Gómez", "vgomez@meteo.gob", "3454-555555", "Emergencias", "LIC-005");
            ResponsableTecnico r6 = s.registrarResponsable("31222333", "Julián", "Ramírez", "jramirez@meteo.gob", "3454-666666", "Instrumental", "LIC-006");
            EquipoRespuesta eq1 = s.crearEquipo("Brigada Litoral Norte");
            eq1.agregarIntegrante(r4);
            eq1.agregarIntegrante(r1);
            EquipoRespuesta eq2 = s.crearEquipo("Brigada Centro-Delta");
            eq2.agregarIntegrante(r5);
            eq2.agregarIntegrante(r3);

            // Estaciones
            EstacionMeteorologica concordia = s.registrarEstacion("Concordia Aero", -31.2970, -57.9960, 35, TipoEstacion.AUTOMATICA, uruguay, r1);
            EstacionMeteorologica salto = s.registrarEstacion("Salto Grande", -31.2750, -57.9400, 40, TipoEstacion.CONVENCIONAL, uruguay, r2);
            EstacionMeteorologica gualeguayE = s.registrarEstacion("Gualeguay Ciudad", -33.1410, -59.3100, 18, TipoEstacion.AUTOMATICA, gualeguay, r3);
            EstacionMeteorologica victoria = s.registrarEstacion("Victoria Puerto", -32.6170, -60.1530, 15, TipoEstacion.CONVENCIONAL, gualeguay, r6);
            EstacionMeteorologica ibicuy = s.registrarEstacion("Ibicuy Isla", -33.7400, -59.1600, 5, TipoEstacion.AUTOMATICA, delta, r6);
            ibicuy.setEstado(EstadoOperativo.FUERA_DE_SERVICIO);

            // Sensores
            Sensor s1 = s.registrarSensor("Davis", "Rain II", 0.2, LocalDate.of(2026, 3, 15));
            Sensor s2 = s.registrarSensor("Davis", "Rain II", 0.2, LocalDate.of(2025, 4, 10)); // requiere calibración
            Sensor s3 = s.registrarSensor("Texas Elec.", "TR-525", 0.25, LocalDate.of(2026, 1, 20));
            Sensor s4 = s.registrarSensor("Vaisala", "RG13", 0.2, LocalDate.of(2026, 6, 5));
            Sensor s5 = s.registrarSensor("Texas Elec.", "TR-525", 0.25, LocalDate.of(2025, 9, 1)); // en mantenimiento
            Sensor s6 = s.registrarSensor("Davis", "Rain II", 0.2, LocalDate.of(2026, 8, 1));      // repuesto, sin instalar
            concordia.instalarSensor(s1);
            concordia.instalarSensor(s2);
            salto.instalarSensor(s3);
            gualeguayE.instalarSensor(s4);
            victoria.instalarSensor(s5);
            s5.setEstado(EstadoOperativo.EN_MANTENIMIENTO);

            // Mantenimientos
            s.registrarMantenimiento(victoria, s5, r6, TipoMantenimiento.CORRECTIVO, LocalDate.of(2026, 10, 5), "Reemplazo de basculante dañado");
            s.registrarMantenimiento(concordia, s1, r2, TipoMantenimiento.PREVENTIVO, LocalDate.of(2026, 6, 20), "Limpieza de embudo y revisión de cableado");
            s.registrarMantenimiento(gualeguayE, null, r3, TipoMantenimiento.PREVENTIVO, LocalDate.of(2026, 7, 12), "Revisión general de la estación");

            // Lecturas de septiembre (para comparar con medias históricas)
            lectura(s, s1, 20, 2026, 9, 5, 7, 0);
            lectura(s, s2, 18, 2026, 9, 10, 18, 0);
            lectura(s, s3, 25, 2026, 9, 12, 9, 0);
            lectura(s, s1, 35, 2026, 9, 18, 15, 0);
            lectura(s, s4, 30, 2026, 9, 8, 8, 0);
            lectura(s, s4, 28, 2026, 9, 22, 8, 0);
            lectura(s, s2, 22, 2026, 9, 20, 18, 0);
            lectura(s, s3, 30, 2026, 9, 28, 9, 0);
            lectura(s, s1, 15, 2026, 9, 25, 7, 0);

            // Episodio de lluvia de octubre (orden cronológico)
            lectura(s, s1, 10, 2026, 10, 10, 6, 0);
            lectura(s, s1, 25, 2026, 10, 10, 18, 0);
            lectura(s, s1, 30, 2026, 10, 11, 6, 0);   // 24 h = 65 mm  -> AMARILLA
            lectura(s, s3, 28, 2026, 10, 11, 8, 0);   // 24 h = 83 mm  -> NARANJA (equipo auto)
            lectura(s, s2, 45, 2026, 10, 11, 12, 0);  // 24 h = 128 mm -> ROJA (equipo auto)
            lectura(s, s1, 5, 2026, 10, 12, 6, 0);    // 24 h = 108 mm -> NARANJA
            lectura(s, s4, 10, 2026, 10, 12, 10, 0);
            lectura(s, s1, 140, 2026, 10, 12, 18, 0); // salto de 135 mm -> ANÓMALA; 24 h = 145 mm -> ROJA
            lectura(s, s4, 55, 2026, 10, 13, 8, 0);   // Gualeguay 24 h = 65 mm -> AMARILLA
            lectura(s, s1, 2, 2026, 10, 14, 9, 0);    // baja de 138 mm -> ANÓMALA; zona vuelve a VERDE
            lectura(s, s4, 3, 2026, 10, 14, 8, 0);

            // Alertas cargadas por operador
            s.registrarAlertaOperador(uruguay, TipoEventoClimatico.CRECIDA_RIO, NivelAlerta.NARANJA,
                    "Río Uruguay supera cota de alerta en Concordia", eq1, LocalDateTime.of(2026, 10, 12, 20, 0));
            s.registrarAlertaOperador(gualeguay, TipoEventoClimatico.TORMENTA_SEVERA, NivelAlerta.AMARILLA,
                    "Tormenta con ráfagas de 80 km/h pronosticada", null, LocalDateTime.of(2026, 10, 13, 15, 30));
            // Se da por atendida la primera alerta del episodio
            uruguay.getAlertas().get(0).marcarAtendida();
        } catch (excepciones.MeteorologiaException e) {
            throw new IllegalStateException("Error al cargar los datos de prueba: " + e.getMessage(), e);
        }
    }

    private static void lectura(SistemaMeteorologico s, Sensor sensor, double mm, int a, int m, int d, int h, int min)
            throws excepciones.MeteorologiaException {
        s.registrarLectura(sensor, mm, LocalDateTime.of(a, m, d, h, min));
    }
}
