package servicio;

import excepciones.MeteorologiaException;
import excepciones.OperacionNoPermitidaException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import modelo.*;

/**
 * Fachada del dominio: mantiene en memoria todas las entidades, genera identificadores,
 * y orquesta los casos de uso (alta de infraestructura y personal, registro de lecturas con
 * disparo automático de alertas, alertas de operador y asignación de equipos).
 */
public class SistemaMeteorologico {

    /**
     * Resultado de registrar una lectura.
     *
     * @param medicion la medición registrada
     * @param alerta   alerta emitida por el cambio de nivel de la zona, o {@code null}
     */
    public record ResultadoLectura(Medicion medicion, Alerta alerta) { }

    private final Map<String, ZonaGeografica> zonas = new LinkedHashMap<>();
    private final Map<String, EstacionMeteorologica> estaciones = new LinkedHashMap<>();
    private final Map<String, Sensor> sensores = new LinkedHashMap<>();
    private final Map<String, ResponsableTecnico> responsables = new LinkedHashMap<>();
    private final Map<String, EquipoRespuesta> equipos = new LinkedHashMap<>();
    private int seqZona, seqEstacion, seqSensor, seqEquipo, seqMantenimiento;

    // ------------------------------------------------------------------ Infraestructura

    /**
     * Registra una zona geográfica.
     *
     * @param nombre nombre
     * @param vuln   vulnerabilidad
     * @param amarilla umbral amarillo
     * @param naranja  umbral naranja
     * @param roja     umbral rojo
     * @return la zona creada
     */
    public ZonaGeografica registrarZona(String nombre, NivelVulnerabilidad vuln,
                                        double amarilla, double naranja, double roja) {
        ZonaGeografica z = new ZonaGeografica(String.format("Z-%02d", ++seqZona), nombre, vuln, amarilla, naranja, roja);
        zonas.put(z.getIdZona(), z);
        return z;
    }

    /**
     * Registra una estación en una zona.
     *
     * @param nombre      nombre
     * @param lat         latitud
     * @param lon         longitud
     * @param alt         altitud
     * @param tipo        tipo
     * @param zona        zona
     * @param responsable responsable técnico
     * @return la estación creada
     */
    public EstacionMeteorologica registrarEstacion(String nombre, double lat, double lon, double alt,
                                                   TipoEstacion tipo, ZonaGeografica zona, ResponsableTecnico responsable) {
        EstacionMeteorologica e = new EstacionMeteorologica(String.format("E-%02d", ++seqEstacion),
                nombre, lat, lon, alt, tipo, zona, responsable);
        estaciones.put(e.getIdEstacion(), e);
        return e;
    }

    /**
     * Registra un sensor (pluviómetro) sin instalar.
     *
     * @param marca marca
     * @param modelo modelo
     * @param precision precisión en mm
     * @param ultimaCalibracion fecha de última calibración
     * @return el sensor creado
     */
    public Sensor registrarSensor(String marca, String modelo, double precision, LocalDate ultimaCalibracion) {
        Sensor s = new Sensor(String.format("S-%02d", ++seqSensor), marca, modelo, precision, ultimaCalibracion);
        sensores.put(s.getIdSensor(), s);
        return s;
    }

    /**
     * Registra un mantenimiento.
     *
     * @param estacion estación
     * @param sensor   sensor (opcional)
     * @param tecnico  responsable
     * @param tipo     tipo
     * @param fecha    fecha
     * @param descripcion detalle
     * @return el mantenimiento creado
     * @throws OperacionNoPermitidaException si el sensor no pertenece a la estación
     */
    public Mantenimiento registrarMantenimiento(EstacionMeteorologica estacion, Sensor sensor,
                                                ResponsableTecnico tecnico, TipoMantenimiento tipo,
                                                LocalDate fecha, String descripcion) throws OperacionNoPermitidaException {
        return new Mantenimiento(String.format("M-%03d", ++seqMantenimiento), fecha, tipo, descripcion,
                estacion, sensor, tecnico);
    }

    // ------------------------------------------------------------------ Personal

    /**
     * Registra un responsable técnico.
     *
     * @param dni DNI
     * @param nombre nombre
     * @param apellido apellido
     * @param correo correo
     * @param celular celular
     * @param especialidad especialidad
     * @param licencia número de licencia
     * @return el técnico creado
     * @throws OperacionNoPermitidaException si ya existe un técnico con ese DNI
     */
    public ResponsableTecnico registrarResponsable(String dni, String nombre, String apellido, String correo,
                                                   String celular, String especialidad, String licencia)
            throws OperacionNoPermitidaException {
        if (responsables.containsKey(dni.trim())) {
            throw new OperacionNoPermitidaException("Ya existe un responsable con DNI " + dni);
        }
        ResponsableTecnico r = new ResponsableTecnico(dni, nombre, apellido, correo, celular, especialidad, licencia);
        responsables.put(r.getDni(), r);
        return r;
    }

    /**
     * Crea un equipo de respuesta vacío.
     *
     * @param nombre nombre del equipo
     * @return el equipo creado
     */
    public EquipoRespuesta crearEquipo(String nombre) {
        EquipoRespuesta e = new EquipoRespuesta(String.format("EQ-%02d", ++seqEquipo), nombre);
        equipos.put(e.getIdEquipo(), e);
        return e;
    }

    // ------------------------------------------------------------------ Lecturas y alertas

    /**
     * Registra una lectura de precipitación y, si cambia el nivel de la zona, actualiza su
     * nivel vigente y emite una alerta LLUVIA_COPIOSA. Si la alerta es NARANJA/ROJA se asigna
     * automáticamente el equipo disponible con menor carga de alertas abiertas.
     *
     * @param sensor sensor que lee
     * @param mm     milímetros
     * @param fh     fecha y hora de la lectura
     * @return medición y alerta eventual
     * @throws MeteorologiaException si la lectura es inválida o el equipo no está operativo
     */
    public ResultadoLectura registrarLectura(Sensor sensor, double mm, LocalDateTime fh) throws MeteorologiaException {
        Medicion m = sensor.registrarLectura(mm, fh);
        Alerta a = sensor.getEstacion().getZona().verificarUmbrales(fh);
        if (a != null && a.requiereEquipo()) {
            EquipoRespuesta e = elegirEquipoDisponible();
            if (e != null) a.asignarEquipo(e);
        }
        return new ResultadoLectura(m, a);
    }

    /**
     * Registra una alerta cargada por un operador (CRECIDA_RIO o TORMENTA_SEVERA).
     *
     * @param zona   zona afectada
     * @param evento tipo de evento (no puede ser LLUVIA_COPIOSA: la genera el sistema)
     * @param nivel  nivel de severidad
     * @param desc   descripción
     * @param equipo equipo de respuesta (obligatorio si el nivel es NARANJA o ROJA)
     * @param fh     fecha y hora
     * @return la alerta emitida
     * @throws OperacionNoPermitidaException si el evento es LLUVIA_COPIOSA o falta el equipo requerido
     */
    public Alerta registrarAlertaOperador(ZonaGeografica zona, TipoEventoClimatico evento, NivelAlerta nivel,
                                          String desc, EquipoRespuesta equipo, LocalDateTime fh)
            throws OperacionNoPermitidaException {
        if (evento == TipoEventoClimatico.LLUVIA_COPIOSA) {
            throw new OperacionNoPermitidaException("Las alertas de LLUVIA_COPIOSA las genera el sistema por umbrales");
        }
        if (nivel.requiereEquipo() && (equipo == null || !equipo.estaConformado())) {
            throw new OperacionNoPermitidaException(
                    "Toda alerta " + nivel + " requiere un equipo de respuesta con al menos un integrante");
        }
        Alerta a = zona.emitirAlerta(evento, nivel, desc, fh);
        if (nivel.requiereEquipo()) a.asignarEquipo(equipo);
        return a;
    }

    /**
     * Asigna (o reasigna) un equipo a una alerta NARANJA/ROJA.
     *
     * @param alerta alerta
     * @param equipo equipo
     * @throws OperacionNoPermitidaException si la alerta no admite equipo o el equipo está vacío
     */
    public void asignarEquipo(Alerta alerta, EquipoRespuesta equipo) throws OperacionNoPermitidaException {
        alerta.asignarEquipo(equipo);
    }

    private EquipoRespuesta elegirEquipoDisponible() {
        return equipos.values().stream()
                .filter(EquipoRespuesta::estaConformado)
                .min(Comparator.comparingLong(this::cargaAbierta))
                .orElse(null);
    }

    private long cargaAbierta(EquipoRespuesta e) {
        return zonas.values().stream().flatMap(z -> z.getAlertas().stream())
                .filter(a -> a.getEquipo() == e && !a.isAtendida()).count();
    }

    // ------------------------------------------------------------------ Consultas

    /** @return todas las alertas de todas las zonas */
    public List<Alerta> getAlertas() {
        List<Alerta> r = new ArrayList<>();
        zonas.values().forEach(z -> r.addAll(z.getAlertas()));
        return r;
    }

    /** @return zonas registradas */
    public List<ZonaGeografica> getZonas() { return new ArrayList<>(zonas.values()); }
    /** @return estaciones registradas */
    public List<EstacionMeteorologica> getEstaciones() { return new ArrayList<>(estaciones.values()); }
    /** @return sensores registrados */
    public List<Sensor> getSensores() { return new ArrayList<>(sensores.values()); }
    /** @return responsables técnicos registrados */
    public List<ResponsableTecnico> getResponsables() { return new ArrayList<>(responsables.values()); }
    /** @return equipos de respuesta registrados */
    public List<EquipoRespuesta> getEquipos() { return new ArrayList<>(equipos.values()); }
}
