package servicio;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalDouble;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import modelo.*;

/**
 * Genera los informes y reportes estadísticos y operativos del sistema como texto.
 */
public class ServicioReportes {
    private final SistemaMeteorologico sistema;

    /**
     * @param sistema sistema del que se leen los datos
     */
    public ServicioReportes(SistemaMeteorologico sistema) {
        this.sistema = sistema;
    }

    private static String fh(LocalDateTime t) { return t.toString().replace('T', ' '); }

    private static LocalDateTime inicio(LocalDate d) { return d.atStartOfDay(); }

    private static LocalDateTime fin(LocalDate d) { return d.atTime(LocalTime.MAX); }

    /**
     * Desvío porcentual del acumulado mensual de una zona respecto de su media histórica.
     *
     * @param zona zona
     * @param ym   mes a evaluar
     * @return porcentaje de desvío, o vacío si no hay media histórica (o es cero)
     */
    public OptionalDouble desviacionPorcentual(ZonaGeografica zona, YearMonth ym) {
        OptionalDouble media = zona.getMediaHistorica(ym.getMonthValue());
        if (media.isEmpty() || media.getAsDouble() == 0) return OptionalDouble.empty();
        double acum = zona.acumulado(inicio(ym.atDay(1)), fin(ym.atEndOfMonth()));
        return OptionalDouble.of((acum - media.getAsDouble()) / media.getAsDouble() * 100.0);
    }

    // ------------------------------------------------------------------ 1. Histórico

    /**
     * Histórico de precipitaciones de una estación (acumulados diarios, semanales y mensuales;
     * los mensuales se comparan con la media histórica de la zona de la estación).
     *
     * @param e estación
     * @return reporte en texto
     */
    public String historico(EstacionMeteorologica e) {
        return historico(e, e.getZona(), "Estación " + e.getNombre());
    }

    /**
     * Histórico de precipitaciones de una zona.
     *
     * @param z zona
     * @return reporte en texto
     */
    public String historico(ZonaGeografica z) {
        return historico(z, z, "Zona " + z.getNombre());
    }

    private String historico(FuenteDePrecipitacion f, ZonaGeografica zonaMedia, String titulo) {
        StringBuilder sb = new StringBuilder("=== HISTÓRICO DE PRECIPITACIONES - " + titulo + " ===\n");
        List<Medicion> ms = f.getMediciones();
        if (ms.isEmpty()) return sb.append("(sin mediciones registradas)\n").toString();

        TreeMap<LocalDate, Double> diario = new TreeMap<>();
        TreeMap<String, Double> semanal = new TreeMap<>();
        TreeMap<YearMonth, Double> mensual = new TreeMap<>();
        for (Medicion m : ms) {
            LocalDate d = m.getFechaHora().toLocalDate();
            double mm = m.getMilimetros();
            diario.merge(d, mm, Double::sum);
            semanal.merge(String.format("%d-S%02d", d.get(IsoFields.WEEK_BASED_YEAR),
                    d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR)), mm, Double::sum);
            mensual.merge(YearMonth.from(d), mm, Double::sum);
        }
        sb.append("\n-- Acumulados diarios --\n");
        diario.forEach((k, v) -> sb.append(String.format("  %s : %8.1f mm%n", k, v)));
        sb.append("\n-- Acumulados semanales (semana ISO) --\n");
        semanal.forEach((k, v) -> sb.append(String.format("  %s : %8.1f mm%n", k, v)));
        sb.append("\n-- Acumulados mensuales vs. media histórica de la zona ").append(zonaMedia.getNombre()).append(" --\n");
        mensual.forEach((k, v) -> {
            OptionalDouble media = zonaMedia.getMediaHistorica(k.getMonthValue());
            sb.append(String.format("  %s : %8.1f mm | media histórica: %s%n", k, v,
                    media.isPresent() ? String.format("%.1f mm", media.getAsDouble()) : "s/d"));
        });
        return sb.toString();
    }

    // ------------------------------------------------------------------ 2. Ranking

    /**
     * Ranking de estaciones por precipitación acumulada en un rango de fechas (mayor a menor).
     *
     * @param desde fecha inicial (inclusive)
     * @param hasta fecha final (inclusive)
     * @return reporte en texto
     */
    public String rankingEstaciones(LocalDate desde, LocalDate hasta) {
        if (desde.isAfter(hasta)) throw new IllegalArgumentException("La fecha 'desde' no puede ser posterior a 'hasta'");
        StringBuilder sb = new StringBuilder("=== RANKING DE ESTACIONES POR VOLUMETRÍA (" + desde + " a " + hasta + ") ===\n");
        List<EstacionMeteorologica> orden = new ArrayList<>(sistema.getEstaciones());
        orden.sort(Comparator.comparingDouble((EstacionMeteorologica e) -> e.acumulado(inicio(desde), fin(hasta))).reversed());
        int pos = 1;
        for (EstacionMeteorologica e : orden) {
            sb.append(String.format("%2d. %-28s %-26s %8.1f mm%n", pos++, e.getNombre(), "(" + e.getZona().getNombre() + ")",
                    e.acumulado(inicio(desde), fin(hasta))));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ 3. Historial de alertas

    /**
     * Historial de alertas filtrado. Cualquier filtro puede ser {@code null} (sin filtrar).
     *
     * @param nivel nivel de severidad
     * @param desde fecha inicial (inclusive)
     * @param hasta fecha final (inclusive)
     * @param zona  zona afectada
     * @return reporte en texto
     */
    public String historialAlertas(NivelAlerta nivel, LocalDate desde, LocalDate hasta, ZonaGeografica zona) {
        List<Alerta> lista = sistema.getAlertas().stream()
                .filter(a -> nivel == null || a.getNivel() == nivel)
                .filter(a -> zona == null || a.getZona() == zona)
                .filter(a -> desde == null || !a.getFechaHoraEmision().isBefore(inicio(desde)))
                .filter(a -> hasta == null || !a.getFechaHoraEmision().isAfter(fin(hasta)))
                .sorted(Comparator.comparing(Alerta::getFechaHoraEmision))
                .collect(Collectors.toList());
        StringBuilder sb = new StringBuilder("=== HISTORIAL DE ALERTAS (nivel: " + (nivel == null ? "todos" : nivel)
                + ", zona: " + (zona == null ? "todas" : zona.getNombre())
                + ", desde: " + (desde == null ? "-" : desde) + ", hasta: " + (hasta == null ? "-" : hasta) + ") ===\n");
        if (lista.isEmpty()) sb.append("(sin alertas para los filtros indicados)\n");
        for (Alerta a : lista) sb.append(a).append("\n     ").append(a.getDescripcion()).append("\n");
        return sb.toString();
    }

    // ------------------------------------------------------------------ 4. Ficha técnica

    /**
     * Ficha técnica operativa de una estación.
     *
     * @param e estación
     * @return reporte en texto
     */
    public String fichaTecnica(EstacionMeteorologica e) {
        StringBuilder sb = new StringBuilder("=== FICHA TÉCNICA OPERATIVA ===\n");
        sb.append(String.format("Estación : %s (%s)%n", e.getNombre(), e.getIdEstacion()));
        sb.append(String.format("Tipo     : %s | Estado: %s%n", e.getTipo(), e.getEstado()));
        sb.append(String.format("Ubicación: lat %.4f, lon %.4f, alt %.0f m%n", e.getLatitud(), e.getLongitud(), e.getAltitud()));
        sb.append(String.format("Zona     : %s | nivel de alerta vigente: %s%n", e.getZona().getNombre(), e.getZona().getNivelAlertaActual()));
        ResponsableTecnico r = e.getResponsable();
        sb.append(String.format("Responsable: %s | %s | %s | %s%n", r.getNombreCompleto(), r.getEspecialidad(),
                r.getCorreoElectronico(), r.getCelular()));
        sb.append("Sensores instalados: ").append(e.getSensores().size()).append("\n");
        for (Sensor s : e.getSensores()) {
            sb.append(String.format("  - %s %s %s | estado %s | calibración: %s%s%n", s.getIdSensor(), s.getMarca(), s.getModelo(),
                    s.getEstado(), s.getUltimaCalibracion(), s.requiereCalibracion() ? " (REQUIERE CALIBRACIÓN)" : ""));
            List<Medicion> ms = s.getMediciones();
            if (ms.isEmpty()) sb.append("      últimas lecturas: (sin lecturas)\n");
            for (int i = Math.max(0, ms.size() - 3); i < ms.size(); i++) sb.append("      ").append(ms.get(i)).append("\n");
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ 5. Fallas y mantenimiento

    /**
     * Informe de fallas y mantenimiento: sensores fuera de servicio o en mantenimiento,
     * lecturas anómalas y sensores que requieren calibración.
     *
     * @return reporte en texto
     */
    public String informeFallas() {
        StringBuilder sb = new StringBuilder("=== INFORME DE FALLAS Y MANTENIMIENTO ===\n");
        sb.append("\n-- Sensores fuera de servicio o en mantenimiento --\n");
        List<Sensor> fuera = sistema.getSensores().stream().filter(s -> s.getEstado() != EstadoOperativo.OPERATIVO).toList();
        if (fuera.isEmpty()) sb.append("  (ninguno)\n");
        fuera.forEach(s -> sb.append("  ").append(s).append("\n"));

        sb.append("\n-- Lecturas anómalas (difieren > ").append((int) Sensor.UMBRAL_ANOMALIA_MM).append(" mm de la anterior) --\n");
        int n = 0;
        for (Sensor s : sistema.getSensores()) {
            for (Medicion m : s.getMediciones()) {
                if (m.isAnomalia()) {
                    n++;
                    sb.append(String.format("  %s | sensor %s | %s%n", fh(m.getFechaHora()), s.getIdSensor(), m));
                }
            }
        }
        if (n == 0) sb.append("  (ninguna)\n");

        sb.append("\n-- Sensores que requieren calibración (> ").append(Sensor.MESES_CALIBRACION).append(" meses) --\n");
        List<Sensor> cal = sistema.getSensores().stream().filter(Sensor::requiereCalibracion).toList();
        if (cal.isEmpty()) sb.append("  (ninguno)\n");
        cal.forEach(s -> sb.append("  ").append(s.getIdSensor()).append(" - última calibración: ")
                .append(s.getUltimaCalibracion()).append("\n"));
        return sb.toString();
    }

    // ------------------------------------------------------------------ 6. Anomalía climática

    /**
     * Estadísticas de anomalía climática: desvío porcentual mensual respecto de la media
     * histórica de la zona.
     *
     * @param z zona
     * @return reporte en texto
     */
    public String anomaliaClimatica(ZonaGeografica z) {
        StringBuilder sb = new StringBuilder("=== ANOMALÍA CLIMÁTICA - " + z.getNombre() + " ===\n");
        TreeSet<YearMonth> meses = z.getMediciones().stream()
                .map(m -> YearMonth.from(m.getFechaHora())).collect(Collectors.toCollection(TreeSet::new));
        if (meses.isEmpty()) return sb.append("(sin mediciones registradas)\n").toString();
        for (YearMonth ym : meses) {
            double acum = z.acumulado(inicio(ym.atDay(1)), fin(ym.atEndOfMonth()));
            OptionalDouble dev = desviacionPorcentual(z, ym);
            OptionalDouble media = z.getMediaHistorica(ym.getMonthValue());
            sb.append(String.format("  %s : acumulado %8.1f mm | media histórica %s | desvío %s%n", ym, acum,
                    media.isPresent() ? String.format("%7.1f mm", media.getAsDouble()) : "    s/d",
                    dev.isPresent() ? String.format("%+.1f%%", dev.getAsDouble()) : "s/d"));
        }
        return sb.toString();
    }
}
