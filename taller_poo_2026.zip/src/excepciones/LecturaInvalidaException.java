package excepciones;

/**
 * Se lanza cuando una lectura de precipitación está fuera del rango físico admitido
 * (0 a 500 mm por lectura) o no es un número válido.
 */
public class LecturaInvalidaException extends MeteorologiaException {
    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción del error
     */
    public LecturaInvalidaException(String mensaje) {
        super(mensaje);
    }
}
