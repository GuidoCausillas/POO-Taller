package excepciones;

/**
 * Se lanza cuando una operación viola una regla de negocio: sensor ya instalado en otra
 * estación, lectura sobre equipo en mantenimiento o fuera de servicio, alerta NARANJA/ROJA
 * sin equipo de respuesta, técnico que ya integra otro equipo, etc.
 */
public class OperacionNoPermitidaException extends MeteorologiaException {
    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción del error
     */
    public OperacionNoPermitidaException(String mensaje) {
        super(mensaje);
    }
}
