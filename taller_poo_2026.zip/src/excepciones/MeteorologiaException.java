package excepciones;

/**
 * Excepción base (verificada) de todas las reglas de negocio del sistema meteorológico.
 */
public class MeteorologiaException extends Exception {
    private static final long serialVersionUID = 1L;

    /**
     * @param mensaje descripción del error
     */
    public MeteorologiaException(String mensaje) {
        super(mensaje);
    }
}
