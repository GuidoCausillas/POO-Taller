package modelo;

/**
 * Técnico responsable de supervisar estaciones, realizar mantenimientos y calibraciones,
 * e integrar un equipo de respuesta ante emergencias (a lo sumo uno).
 */
public class ResponsableTecnico extends Persona {
    private String especialidad;
    private String numeroLicencia;
    private boolean disponible = true;
    private EquipoRespuesta equipo;

    /**
     * @param dni               DNI
     * @param nombre            nombre
     * @param apellido          apellido
     * @param correoElectronico correo
     * @param celular           celular
     * @param especialidad      especialidad técnica
     * @param numeroLicencia    número de licencia profesional
     */
    public ResponsableTecnico(String dni, String nombre, String apellido, String correoElectronico,
                              String celular, String especialidad, String numeroLicencia) {
        super(dni, nombre, apellido, correoElectronico, celular);
        this.especialidad = especialidad;
        this.numeroLicencia = numeroLicencia;
    }

    /** @return especialidad */
    public String getEspecialidad() { return especialidad; }
    /** @return número de licencia */
    public String getNumeroLicencia() { return numeroLicencia; }
    /** @return {@code true} si está disponible para tareas/emergencias */
    public boolean isDisponible() { return disponible; }
    /** @param disponible nueva disponibilidad */
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
    /** @return equipo de respuesta que integra, o {@code null} */
    public EquipoRespuesta getEquipo() { return equipo; }

    /** Uso interno: lo invoca {@link EquipoRespuesta#agregarIntegrante}. */
    void setEquipo(EquipoRespuesta equipo) { this.equipo = equipo; }

    @Override
    public String toString() {
        return getNombreCompleto() + " - " + especialidad;
    }
}
