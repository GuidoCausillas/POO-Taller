package modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.OptionalDouble;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Zona geográfica o cuenca hidrográfica. Agrupa estaciones, define los tres umbrales de
 * lluvia acumulada en 24 horas, mantiene su nivel de alerta vigente, sus valores históricos
 * mensuales y las alertas que emite.
 */
public class ZonaGeografica implements FuenteDePrecipitacion {
    private final String idZona;
    private String nombre;
    private NivelVulnerabilidad nivelVulnerabilidad;
    private double umbralAmarilla;
    private double umbralNaranja;
    private double umbralRoja;
    private NivelAlerta nivelAlertaActual = NivelAlerta.VERDE;
    private final List<EstacionMeteorologica> estaciones = new ArrayList<>();
    private final TreeMap<Integer, ValorHistorico> valoresHistoricos = new TreeMap<>();
    private final List<Alerta> alertas = new ArrayList<>();

    /**
     * @param idZona              identificador
     * @param nombre              nombre de la zona o cuenca
     * @param nivelVulnerabilidad vulnerabilidad climática
     * @param umbralAmarilla      umbral amarillo (mm en 24 h)
     * @param umbralNaranja       umbral naranja (mm en 24 h)
     * @param umbralRoja          umbral rojo (mm en 24 h)
     * @throws IllegalArgumentException si no se cumple 0 &lt; amarilla &lt; naranja &lt; roja
     */
    public ZonaGeografica(String idZona, String nombre, NivelVulnerabilidad nivelVulnerabilidad,
                          double umbralAmarilla, double umbralNaranja, double umbralRoja) {
        this.idZona = idZona;
        this.nombre = nombre;
        this.nivelVulnerabilidad = nivelVulnerabilidad;
        configurarUmbrales(umbralAmarilla, umbralNaranja, umbralRoja);
    }

    /**
     * Configura los umbrales validando que sean estrictamente crecientes.
     *
     * @param amarilla umbral amarillo
     * @param naranja  umbral naranja
     * @param roja     umbral rojo
     * @throws IllegalArgumentException si no se cumple 0 &lt; amarilla &lt; naranja &lt; roja
     */
    public final void configurarUmbrales(double amarilla, double naranja, double roja) {
        if (!(amarilla > 0 && amarilla < naranja && naranja < roja)) {
            throw new IllegalArgumentException("Los umbrales deben cumplir 0 < amarilla < naranja < roja");
        }
        this.umbralAmarilla = amarilla;
        this.umbralNaranja = naranja;
        this.umbralRoja = roja;
    }

    /**
     * Lluvia acumulada por todas las estaciones de la zona en las 24 horas previas a una
     * fecha de referencia (ventana inclusiva).
     *
     * @param referencia instante final de la ventana
     * @return milímetros acumulados
     */
    public double lluviaAcumulada24H(LocalDateTime referencia) {
        return acumulado(referencia.minusHours(24), referencia);
    }

    /**
     * Determina el nivel de riesgo según el acumulado de 24 h, sin modificar el estado.
     *
     * @param referencia instante final de la ventana de 24 h
     * @return VERDE si está bajo el umbral amarillo; de lo contrario el nivel del mayor umbral alcanzado
     */
    public NivelAlerta evaluarRiesgo(LocalDateTime referencia) {
        double acum = lluviaAcumulada24H(referencia);
        if (acum >= umbralRoja) return NivelAlerta.ROJA;
        if (acum >= umbralNaranja) return NivelAlerta.NARANJA;
        if (acum >= umbralAmarilla) return NivelAlerta.AMARILLA;
        return NivelAlerta.VERDE;
    }

    /**
     * Reevalúa el riesgo; si el nivel cambió, actualiza el nivel vigente y emite una alerta
     * LLUVIA_COPIOSA con el nuevo nivel (VERDE significa retorno a la normalidad).
     *
     * @param referencia instante final de la ventana de 24 h
     * @return la alerta emitida, o {@code null} si el nivel no cambió
     */
    public Alerta verificarUmbrales(LocalDateTime referencia) {
        NivelAlerta nuevo = evaluarRiesgo(referencia);
        if (nuevo == nivelAlertaActual) return null;
        nivelAlertaActual = nuevo;
        String desc = String.format("Acumulado en 24 h: %.1f mm (umbrales %.0f/%.0f/%.0f)%s",
                lluviaAcumulada24H(referencia), umbralAmarilla, umbralNaranja, umbralRoja,
                nuevo == NivelAlerta.VERDE ? " - retorno a la normalidad" : "");
        return emitirAlerta(TipoEventoClimatico.LLUVIA_COPIOSA, nuevo, desc, referencia);
    }

    /**
     * Crea y registra una alerta de la zona.
     *
     * @param evento      tipo de evento
     * @param nivel       severidad
     * @param descripcion detalle
     * @param fechaHora   instante de emisión
     * @return la alerta emitida
     */
    public Alerta emitirAlerta(TipoEventoClimatico evento, NivelAlerta nivel, String descripcion,
                               LocalDateTime fechaHora) {
        Alerta a = new Alerta(idZona + "-A" + String.format("%03d", alertas.size() + 1),
                fechaHora, nivel, evento, descripcion, this);
        alertas.add(a);
        return a;
    }

    /**
     * Define el acumulado medio histórico de un mes.
     *
     * @param mes            mes (1 a 12)
     * @param acumuladoMedio media en mm
     */
    public void setValorHistorico(int mes, double acumuladoMedio) {
        valoresHistoricos.put(mes, new ValorHistorico(mes, acumuladoMedio));
    }

    /**
     * @param mes mes (1 a 12)
     * @return media histórica del mes, o vacío si no está cargada
     */
    public OptionalDouble getMediaHistorica(int mes) {
        ValorHistorico v = valoresHistoricos.get(mes);
        return v == null ? OptionalDouble.empty() : OptionalDouble.of(v.getAcumuladoMedio());
    }

    /** Uso interno: lo invoca el constructor de {@link EstacionMeteorologica}. */
    void agregarEstacion(EstacionMeteorologica e) { estaciones.add(e); }

    /** @return mediciones de todas las estaciones de la zona */
    @Override
    public List<Medicion> getMediciones() {
        return estaciones.stream().flatMap(e -> e.getMediciones().stream()).collect(Collectors.toList());
    }

    /** @return identificador */
    public String getIdZona() { return idZona; }
    @Override
    public String getNombre() { return nombre; }
    /** @return vulnerabilidad climática */
    public NivelVulnerabilidad getNivelVulnerabilidad() { return nivelVulnerabilidad; }
    /** @return umbral amarillo (mm/24 h) */
    public double getUmbralAmarilla() { return umbralAmarilla; }
    /** @return umbral naranja (mm/24 h) */
    public double getUmbralNaranja() { return umbralNaranja; }
    /** @return umbral rojo (mm/24 h) */
    public double getUmbralRoja() { return umbralRoja; }
    /** @return nivel de alerta vigente */
    public NivelAlerta getNivelAlertaActual() { return nivelAlertaActual; }
    /** @return estaciones de la zona (solo lectura) */
    public List<EstacionMeteorologica> getEstaciones() { return Collections.unmodifiableList(estaciones); }
    /** @return alertas emitidas (solo lectura) */
    public List<Alerta> getAlertas() { return Collections.unmodifiableList(alertas); }

    @Override
    public String toString() {
        return idZona + " - " + nombre + " (vulnerabilidad " + nivelVulnerabilidad + ", nivel actual "
                + nivelAlertaActual + ", umbrales " + (int) umbralAmarilla + "/" + (int) umbralNaranja + "/"
                + (int) umbralRoja + " mm)";
    }
}
