package modelo;

/**
 * Severidad de una alerta, de menor a mayor. El orden de declaración refleja la gravedad.
 */
public enum NivelAlerta {
    VERDE("Verde"), AMARILLA("Amarilla"), NARANJA("Naranja"), ROJA("Roja");

    private final String etiqueta;

    NivelAlerta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    /**
     * @return {@code true} si el nivel es NARANJA o ROJA, es decir, exige asignar un
     *         {@link EquipoRespuesta}
     */
    public boolean requiereEquipo() {
        return this == NARANJA || this == ROJA;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
