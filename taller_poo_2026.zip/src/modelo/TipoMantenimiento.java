package modelo;

/** Tipo de tarea de mantenimiento realizada sobre una estación o sensor. */
public enum TipoMantenimiento {
    PREVENTIVO, CORRECTIVO, CALIBRACION
}
