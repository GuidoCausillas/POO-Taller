package modelo;

/**
 * Clase abstracta con los datos básicos de identificación de una persona.
 * Es la superclase de {@link ResponsableTecnico}.
 */
public abstract class Persona {
    private final String dni;
    private String nombre;
    private String apellido;
    private String correoElectronico;
    private String celular;

    /**
     * @param dni               documento (obligatorio, identifica a la persona)
     * @param nombre            nombre (obligatorio)
     * @param apellido          apellido (obligatorio)
     * @param correoElectronico correo de contacto
     * @param celular           celular de contacto
     * @throws IllegalArgumentException si dni, nombre o apellido están vacíos
     */
    protected Persona(String dni, String nombre, String apellido, String correoElectronico, String celular) {
        if (dni == null || dni.isBlank()) throw new IllegalArgumentException("El DNI es obligatorio");
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("El nombre es obligatorio");
        if (apellido == null || apellido.isBlank()) throw new IllegalArgumentException("El apellido es obligatorio");
        this.dni = dni.trim();
        this.nombre = nombre.trim();
        this.apellido = apellido.trim();
        this.correoElectronico = correoElectronico;
        this.celular = celular;
    }

    /** @return DNI */
    public String getDni() { return dni; }
    /** @return nombre */
    public String getNombre() { return nombre; }
    /** @return apellido */
    public String getApellido() { return apellido; }
    /** @return correo electrónico */
    public String getCorreoElectronico() { return correoElectronico; }
    /** @return celular */
    public String getCelular() { return celular; }

    /** @param correoElectronico nuevo correo */
    public void setCorreoElectronico(String correoElectronico) { this.correoElectronico = correoElectronico; }
    /** @param celular nuevo celular */
    public void setCelular(String celular) { this.celular = celular; }

    /** @return "Nombre Apellido" */
    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    @Override
    public String toString() {
        return getNombreCompleto() + " (DNI " + dni + ")";
    }
}
