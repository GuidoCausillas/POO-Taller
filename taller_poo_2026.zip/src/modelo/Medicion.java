package modelo;

import java.time.LocalDateTime;

/**
 * Lectura de precipitación tomada por un {@link Sensor}. Es inmutable: una vez
 * registrada no se modifica. Solo el sensor puede crearla (composición).
 */
public class Medicion {
    private final String idMedicion;
    private final LocalDateTime fechaHora;
    private final double milimetros;
    private final boolean anomalia;

    Medicion(String idMedicion, LocalDateTime fechaHora, double milimetros, boolean anomalia) {
        this.idMedicion = idMedicion;
        this.fechaHora = fechaHora;
        this.milimetros = milimetros;
        this.anomalia = anomalia;
    }

    /** @return identificador */
    public String getIdMedicion() { return idMedicion; }
    /** @return fecha y hora de la lectura */
    public LocalDateTime getFechaHora() { return fechaHora; }
    /** @return milímetros registrados */
    public double getMilimetros() { return milimetros; }
    /** @return {@code true} si difiere de la lectura anterior del sensor en más de 100 mm */
    public boolean isAnomalia() { return anomalia; }

    @Override
    public String toString() {
        return String.format("%s | %.1f mm%s", fechaHora.toString().replace('T', ' '), milimetros,
                anomalia ? " [ANÓMALA]" : "");
    }
}
