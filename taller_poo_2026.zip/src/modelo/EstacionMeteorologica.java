package modelo;

import excepciones.OperacionNoPermitidaException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Estación meteorológica. Pertenece a exactamente una {@link ZonaGeografica}, está a cargo
 * de un {@link ResponsableTecnico} y agrega (0..*) {@link Sensor}es que pueden trasladarse
 * entre estaciones.
 */
public final class EstacionMeteorologica implements FuenteDePrecipitacion {
    private final String idEstacion;
    private String nombre;
    private double latitud;
    private double longitud;
    private double altitud;
    private EstadoOperativo estado = EstadoOperativo.OPERATIVO;
    private final TipoEstacion tipo;
    private final ZonaGeografica zona;
    private ResponsableTecnico responsable;
    private final List<Sensor> sensores = new ArrayList<>();
    private final List<Mantenimiento> mantenimientos = new ArrayList<>();

    /**
     * Crea la estación y la registra en su zona.
     *
     * @param idEstacion  identificador
     * @param nombre      nombre
     * @param latitud     latitud
     * @param longitud    longitud
     * @param altitud     altitud (m s. n. m.)
     * @param tipo        automática o convencional
     * @param zona        zona a la que pertenece (obligatoria)
     * @param responsable técnico a cargo (obligatorio)
     */
    public EstacionMeteorologica(String idEstacion, String nombre, double latitud, double longitud,
                                 double altitud, TipoEstacion tipo, ZonaGeografica zona,
                                 ResponsableTecnico responsable) {
        if (zona == null) throw new IllegalArgumentException("La estación debe pertenecer a una zona");
        if (responsable == null) throw new IllegalArgumentException("La estación debe tener un responsable técnico");
        this.idEstacion = idEstacion;
        this.nombre = nombre;
        this.latitud = latitud;
        this.longitud = longitud;
        this.altitud = altitud;
        this.tipo = tipo;
        this.zona = zona;
        this.responsable = responsable;
        zona.agregarEstacion(this);
    }

    /**
     * Instala un sensor en esta estación.
     *
     * @param s sensor a instalar
     * @throws OperacionNoPermitidaException si el sensor ya está instalado en una estación
     *                                       (regla de asignación única)
     */
    public void instalarSensor(Sensor s) throws OperacionNoPermitidaException {
        if (s == null) throw new IllegalArgumentException("El sensor no puede ser nulo");
        if (s.getEstacion() != null) {
            throw new OperacionNoPermitidaException("El sensor " + s.getIdSensor() + " ya está instalado en '"
                    + s.getEstacion().getNombre() + "'. Debe retirarse antes de instalarlo en otra estación");
        }
        sensores.add(s);
        s.setEstacion(this);
    }

    /**
     * Retira un sensor de esta estación, dejándolo disponible para instalarse en otra.
     *
     * @param s sensor a retirar
     * @throws OperacionNoPermitidaException si el sensor no está instalado en esta estación
     */
    public void retirarSensor(Sensor s) throws OperacionNoPermitidaException {
        if (s == null || !sensores.remove(s)) {
            throw new OperacionNoPermitidaException("El sensor indicado no está instalado en '" + nombre + "'");
        }
        s.setEstacion(null);
    }

    /** @return {@code true} si el estado de la estación es OPERATIVO */
    public boolean estaOperativa() {
        return estado == EstadoOperativo.OPERATIVO;
    }

    /** Uso interno: lo invoca el constructor de {@link Mantenimiento}. */
    void agregarMantenimiento(Mantenimiento m) { mantenimientos.add(m); }

    /** @return mediciones de todos los sensores actualmente instalados */
    @Override
    public List<Medicion> getMediciones() {
        return sensores.stream().flatMap(s -> s.getMediciones().stream()).collect(Collectors.toList());
    }

    /** @return identificador */
    public String getIdEstacion() { return idEstacion; }
    @Override
    public String getNombre() { return nombre; }
    /** @return latitud */
    public double getLatitud() { return latitud; }
    /** @return longitud */
    public double getLongitud() { return longitud; }
    /** @return altitud */
    public double getAltitud() { return altitud; }
    /** @return estado operativo */
    public EstadoOperativo getEstado() { return estado; }
    /** @param estado nuevo estado operativo */
    public void setEstado(EstadoOperativo estado) { this.estado = estado; }
    /** @return tipo de estación */
    public TipoEstacion getTipo() { return tipo; }
    /** @return zona a la que pertenece */
    public ZonaGeografica getZona() { return zona; }
    /** @return responsable técnico a cargo */
    public ResponsableTecnico getResponsable() { return responsable; }
    /** @param responsable nuevo responsable (obligatorio) */
    public void setResponsable(ResponsableTecnico responsable) {
        if (responsable == null) throw new IllegalArgumentException("El responsable no puede ser nulo");
        this.responsable = responsable;
    }
    /** @return sensores instalados (solo lectura) */
    public List<Sensor> getSensores() { return Collections.unmodifiableList(sensores); }
    /** @return mantenimientos realizados (solo lectura) */
    public List<Mantenimiento> getMantenimientos() { return Collections.unmodifiableList(mantenimientos); }

    @Override
    public String toString() {
        return idEstacion + " - " + nombre + " (" + tipo + ", " + estado + ") - zona " + zona.getNombre();
    }
}
