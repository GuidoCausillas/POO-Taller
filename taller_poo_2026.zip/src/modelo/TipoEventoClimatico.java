package modelo;

/** Tipo de evento que origina una alerta. */
public enum TipoEventoClimatico {
    LLUVIA_COPIOSA("Lluvia Copiosa"), CRECIDA_RIO("Crecida de Río"), TORMENTA_SEVERA("Tormenta Severa");

    private final String etiqueta;

    TipoEventoClimatico(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
