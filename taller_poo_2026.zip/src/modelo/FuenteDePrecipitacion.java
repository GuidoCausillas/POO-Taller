package modelo;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Abstracción de cualquier entidad que pueda consultarse como fuente de lecturas de
 * precipitación (una {@link EstacionMeteorologica} o una {@link ZonaGeografica}).
 * Permite que los reportes traten ambos casos de forma polimórfica.
 */
public interface FuenteDePrecipitacion {

    /** @return nombre descriptivo de la fuente */
    String getNombre();

    /** @return todas las mediciones disponibles de la fuente */
    List<Medicion> getMediciones();

    /**
     * Suma los milímetros registrados en un intervalo de tiempo.
     *
     * @param desde inicio del intervalo (inclusive)
     * @param hasta fin del intervalo (inclusive)
     * @return milímetros acumulados
     */
    default double acumulado(LocalDateTime desde, LocalDateTime hasta) {
        return getMediciones().stream()
                .filter(m -> !m.getFechaHora().isBefore(desde) && !m.getFechaHora().isAfter(hasta))
                .mapToDouble(Medicion::getMilimetros)
                .sum();
    }
}
