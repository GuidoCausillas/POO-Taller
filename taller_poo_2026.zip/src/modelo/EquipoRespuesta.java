package modelo;

import excepciones.OperacionNoPermitidaException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Equipo técnico de respuesta a emergencias, integrado por uno o más responsables técnicos.
 * Cada técnico integra a lo sumo un equipo.
 */
public class EquipoRespuesta {
    private final String idEquipo;
    private String nombreEquipo;
    private final List<ResponsableTecnico> integrantes = new ArrayList<>();

    /**
     * @param idEquipo     identificador
     * @param nombreEquipo nombre descriptivo
     */
    public EquipoRespuesta(String idEquipo, String nombreEquipo) {
        this.idEquipo = idEquipo;
        this.nombreEquipo = nombreEquipo;
    }

    /**
     * Agrega un técnico al equipo.
     *
     * @param r técnico a incorporar
     * @throws OperacionNoPermitidaException si el técnico ya integra un equipo
     */
    public void agregarIntegrante(ResponsableTecnico r) throws OperacionNoPermitidaException {
        if (r == null) throw new IllegalArgumentException("El técnico no puede ser nulo");
        if (r.getEquipo() != null) {
            throw new OperacionNoPermitidaException(
                    r.getNombreCompleto() + " ya integra el equipo '" + r.getEquipo().getNombreEquipo() + "'");
        }
        integrantes.add(r);
        r.setEquipo(this);
    }

    /** @return {@code true} si tiene al menos un integrante (condición para ser asignable) */
    public boolean estaConformado() { return !integrantes.isEmpty(); }

    /** @return identificador */
    public String getIdEquipo() { return idEquipo; }
    /** @return nombre */
    public String getNombreEquipo() { return nombreEquipo; }
    /** @return integrantes (vista de solo lectura) */
    public List<ResponsableTecnico> getIntegrantes() { return Collections.unmodifiableList(integrantes); }

    @Override
    public String toString() {
        return idEquipo + " - " + nombreEquipo + " (" + integrantes.size() + " integrante/s)";
    }
}
