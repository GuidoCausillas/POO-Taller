package modelo;

import excepciones.OperacionNoPermitidaException;
import java.time.LocalDateTime;

/**
 * Alerta emitida por una {@link ZonaGeografica}. Si su nivel es NARANJA o ROJA requiere
 * la asignación de un {@link EquipoRespuesta}.
 */
public class Alerta {
    private final String idAlerta;
    private final LocalDateTime fechaHoraEmision;
    private final NivelAlerta nivel;
    private final TipoEventoClimatico evento;
    private final String descripcion;
    private final ZonaGeografica zona;
    private boolean atendida;
    private EquipoRespuesta equipo;

    Alerta(String idAlerta, LocalDateTime fechaHoraEmision, NivelAlerta nivel, TipoEventoClimatico evento,
           String descripcion, ZonaGeografica zona) {
        this.idAlerta = idAlerta;
        this.fechaHoraEmision = fechaHoraEmision;
        this.nivel = nivel;
        this.evento = evento;
        this.descripcion = descripcion;
        this.zona = zona;
    }

    /**
     * Asigna el equipo de respuesta que atenderá la alerta.
     *
     * @param e equipo a asignar
     * @throws OperacionNoPermitidaException si el nivel no es NARANJA/ROJA o el equipo no tiene integrantes
     */
    public void asignarEquipo(EquipoRespuesta e) throws OperacionNoPermitidaException {
        if (!requiereEquipo()) {
            throw new OperacionNoPermitidaException("Una alerta de nivel " + nivel + " no admite equipo de respuesta");
        }
        if (e == null || !e.estaConformado()) {
            throw new OperacionNoPermitidaException("Debe asignarse un equipo con al menos un integrante");
        }
        this.equipo = e;
    }

    /** @return {@code true} si el nivel es NARANJA o ROJA */
    public boolean requiereEquipo() { return nivel.requiereEquipo(); }

    /** @return {@code true} si requiere equipo y todavía no lo tiene asignado */
    public boolean estaPendienteDeEquipo() { return requiereEquipo() && equipo == null; }

    /** Marca la alerta como atendida. */
    public void marcarAtendida() { this.atendida = true; }

    /** @return identificador */
    public String getIdAlerta() { return idAlerta; }
    /** @return fecha y hora de emisión */
    public LocalDateTime getFechaHoraEmision() { return fechaHoraEmision; }
    /** @return nivel de severidad */
    public NivelAlerta getNivel() { return nivel; }
    /** @return tipo de evento */
    public TipoEventoClimatico getEvento() { return evento; }
    /** @return descripción */
    public String getDescripcion() { return descripcion; }
    /** @return zona que emitió la alerta */
    public ZonaGeografica getZona() { return zona; }
    /** @return {@code true} si fue atendida */
    public boolean isAtendida() { return atendida; }
    /** @return equipo asignado o {@code null} */
    public EquipoRespuesta getEquipo() { return equipo; }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s | %s | equipo: %s | %s",
                idAlerta, fechaHoraEmision.toString().replace('T', ' '), nivel, evento, zona.getNombre(),
                equipo != null ? equipo.getNombreEquipo() : (requiereEquipo() ? "PENDIENTE" : "-"),
                atendida ? "atendida" : "abierta");
    }
}
