package modelo;

/** Estado operativo de una estación o de un sensor. */
public enum EstadoOperativo {
    OPERATIVO, EN_MANTENIMIENTO, FUERA_DE_SERVICIO
}
