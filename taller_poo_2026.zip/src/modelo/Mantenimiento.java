package modelo;

import excepciones.OperacionNoPermitidaException;
import java.time.LocalDate;

/**
 * Tarea de mantenimiento de una estación, opcionalmente aplicada a un sensor puntual y
 * realizada por un {@link ResponsableTecnico}. Si es de tipo CALIBRACION sobre un sensor,
 * actualiza la fecha de última calibración del mismo.
 */
public final class Mantenimiento {
    private final String idMantenimiento;
    private final LocalDate fecha;
    private final TipoMantenimiento tipo;
    private final String descripcion;
    private final EstacionMeteorologica estacion;
    private final Sensor sensor;
    private final ResponsableTecnico responsable;

    /**
     * @param idMantenimiento identificador
     * @param fecha           fecha de realización
     * @param tipo            tipo de mantenimiento
     * @param descripcion     detalle de la tarea
     * @param estacion        estación (obligatoria)
     * @param sensor          sensor alcanzado, o {@code null} si es sobre toda la estación
     * @param responsable     técnico que lo realiza (obligatorio)
     * @throws OperacionNoPermitidaException si el sensor no pertenece a la estación indicada
     */
    public Mantenimiento(String idMantenimiento, LocalDate fecha, TipoMantenimiento tipo, String descripcion,
                         EstacionMeteorologica estacion, Sensor sensor, ResponsableTecnico responsable)
            throws OperacionNoPermitidaException {
        if (estacion == null || responsable == null || fecha == null || tipo == null) {
            throw new IllegalArgumentException("Fecha, tipo, estación y responsable son obligatorios");
        }
        if (sensor != null && sensor.getEstacion() != estacion) {
            throw new OperacionNoPermitidaException("El sensor " + sensor.getIdSensor()
                    + " no está instalado en la estación '" + estacion.getNombre() + "'");
        }
        this.idMantenimiento = idMantenimiento;
        this.fecha = fecha;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.estacion = estacion;
        this.sensor = sensor;
        this.responsable = responsable;
        estacion.agregarMantenimiento(this);
        if (tipo == TipoMantenimiento.CALIBRACION && sensor != null) sensor.registrarCalibracion(fecha);
    }

    /** @return identificador */
    public String getIdMantenimiento() { return idMantenimiento; }
    /** @return fecha */
    public LocalDate getFecha() { return fecha; }
    /** @return tipo */
    public TipoMantenimiento getTipo() { return tipo; }
    /** @return descripción */
    public String getDescripcion() { return descripcion; }
    /** @return estación */
    public EstacionMeteorologica getEstacion() { return estacion; }
    /** @return sensor alcanzado o {@code null} */
    public Sensor getSensor() { return sensor; }
    /** @return técnico que lo realizó */
    public ResponsableTecnico getResponsable() { return responsable; }

    @Override
    public String toString() {
        return fecha + " | " + tipo + " | " + estacion.getNombre()
                + (sensor != null ? " / sensor " + sensor.getIdSensor() : "")
                + " | " + responsable.getNombreCompleto() + " | " + descripcion;
    }
}
