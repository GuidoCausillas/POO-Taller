package modelo;

import excepciones.LecturaInvalidaException;
import excepciones.OperacionNoPermitidaException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pluviómetro. Está instalado en a lo sumo una {@link EstacionMeteorologica} y compone
 * su propio historial de {@link Medicion}.
 */
public class Sensor {
    /** Mínimo físico admitido por lectura (mm). */
    public static final double MM_MINIMO = 0.0;
    /** Máximo físico admitido por lectura (mm). */
    public static final double MM_MAXIMO = 500.0;
    /** Diferencia (mm) respecto de la lectura anterior a partir de la cual se marca anomalía. */
    public static final double UMBRAL_ANOMALIA_MM = 100.0;
    /** Meses sin calibrar a partir de los cuales el sensor requiere calibración. */
    public static final int MESES_CALIBRACION = 12;

    private final String idSensor;
    private String marca;
    private String modelo;
    private double precision;
    private EstadoOperativo estado = EstadoOperativo.OPERATIVO;
    private LocalDate ultimaCalibracion;
    private EstacionMeteorologica estacion;
    private final List<Medicion> mediciones = new ArrayList<>();

    /**
     * @param idSensor           identificador
     * @param marca              marca
     * @param modelo             modelo
     * @param precision          precisión en mm
     * @param ultimaCalibracion  fecha de la última calibración
     */
    public Sensor(String idSensor, String marca, String modelo, double precision, LocalDate ultimaCalibracion) {
        this.idSensor = idSensor;
        this.marca = marca;
        this.modelo = modelo;
        this.precision = precision;
        this.ultimaCalibracion = ultimaCalibracion;
    }

    /**
     * Indica si un valor está dentro del rango físico admitido.
     *
     * @param mm milímetros a validar
     * @return {@code true} si 0 &le; mm &le; 500
     */
    public boolean validar(double mm) {
        return !Double.isNaN(mm) && mm >= MM_MINIMO && mm <= MM_MAXIMO;
    }

    /**
     * Registra una lectura aplicando las reglas de negocio: control operativo (sensor y
     * estación deben estar OPERATIVOS), validación de rango y detección de lectura anómala.
     *
     * @param mm milímetros leídos
     * @param fh fecha y hora de la lectura
     * @return la medición creada
     * @throws OperacionNoPermitidaException si el sensor no está instalado, o el sensor o su
     *                                       estación están EN_MANTENIMIENTO o FUERA_DE_SERVICIO
     * @throws LecturaInvalidaException      si el valor está fuera de 0..500 mm
     */
    public Medicion registrarLectura(double mm, LocalDateTime fh)
            throws OperacionNoPermitidaException, LecturaInvalidaException {
        if (fh == null) throw new IllegalArgumentException("La fecha y hora es obligatoria");
        if (estacion == null) {
            throw new OperacionNoPermitidaException("El sensor " + idSensor + " no está instalado en ninguna estación");
        }
        if (estado != EstadoOperativo.OPERATIVO) {
            throw new OperacionNoPermitidaException("El sensor " + idSensor + " está " + estado + ": no admite lecturas");
        }
        if (!estacion.estaOperativa()) {
            throw new OperacionNoPermitidaException("La estación " + estacion.getNombre() + " está "
                    + estacion.getEstado() + ": no admite lecturas");
        }
        if (!validar(mm)) {
            throw new LecturaInvalidaException(String.format(
                    "Lectura %.1f mm fuera de rango físico (%.0f a %.0f mm)", mm, MM_MINIMO, MM_MAXIMO));
        }
        boolean anomala = !mediciones.isEmpty()
                && Math.abs(mm - mediciones.get(mediciones.size() - 1).getMilimetros()) > UMBRAL_ANOMALIA_MM;
        Medicion m = new Medicion(idSensor + "-M" + String.format("%04d", mediciones.size() + 1), fh, mm, anomala);
        mediciones.add(m);
        return m;
    }

    /**
     * @return {@code true} si pasaron más de 12 meses desde la última calibración (o nunca se calibró)
     */
    public boolean requiereCalibracion() {
        return requiereCalibracion(LocalDate.now());
    }

    /**
     * @param hoy fecha de referencia
     * @return {@code true} si pasaron más de 12 meses desde la última calibración a la fecha dada
     */
    public boolean requiereCalibracion(LocalDate hoy) {
        return ultimaCalibracion == null || ultimaCalibracion.plusMonths(MESES_CALIBRACION).isBefore(hoy);
    }

    /**
     * Registra una calibración; solo avanza la fecha si es posterior a la vigente.
     *
     * @param fecha fecha de la calibración
     */
    public void registrarCalibracion(LocalDate fecha) {
        if (ultimaCalibracion == null || fecha.isAfter(ultimaCalibracion)) ultimaCalibracion = fecha;
    }

    /** @return la última medición registrada o {@code null} */
    public Medicion getUltimaMedicion() {
        return mediciones.isEmpty() ? null : mediciones.get(mediciones.size() - 1);
    }

    /** @return identificador */
    public String getIdSensor() { return idSensor; }
    /** @return marca */
    public String getMarca() { return marca; }
    /** @return modelo */
    public String getModelo() { return modelo; }
    /** @return precisión en mm */
    public double getPrecision() { return precision; }
    /** @return estado operativo */
    public EstadoOperativo getEstado() { return estado; }
    /** @param estado nuevo estado operativo */
    public void setEstado(EstadoOperativo estado) { this.estado = estado; }
    /** @return fecha de última calibración */
    public LocalDate getUltimaCalibracion() { return ultimaCalibracion; }
    /** @return estación donde está instalado, o {@code null} */
    public EstacionMeteorologica getEstacion() { return estacion; }
    /** @return historial de mediciones (solo lectura) */
    public List<Medicion> getMediciones() { return Collections.unmodifiableList(mediciones); }

    /** Uso interno: lo invoca {@link EstacionMeteorologica}. */
    void setEstacion(EstacionMeteorologica estacion) { this.estacion = estacion; }

    @Override
    public String toString() {
        return idSensor + " - " + marca + " " + modelo + " [" + estado + "]"
                + (estacion != null ? " en " + estacion.getNombre() : " (sin instalar)");
    }
}
