package modelo;

/** Tipo de estación meteorológica. */
public enum TipoEstacion {
    AUTOMATICA, CONVENCIONAL
}
