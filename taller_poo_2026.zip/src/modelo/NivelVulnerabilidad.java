package modelo;

/** Nivel de vulnerabilidad climática de una zona geográfica o cuenca. */
public enum NivelVulnerabilidad {
    BAJO, MEDIO, ALTO, MUY_ALTO
}
