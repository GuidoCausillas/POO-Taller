package modelo;

/**
 * Acumulado medio histórico de precipitación (mm) de una zona para un mes del año.
 * Se compone dentro de {@link ZonaGeografica}.
 */
public class ValorHistorico {
    private final int mes;
    private final double acumuladoMedio;

    /**
     * @param mes            número de mes (1 a 12)
     * @param acumuladoMedio acumulado medio en mm (&ge; 0)
     */
    ValorHistorico(int mes, double acumuladoMedio) {
        if (mes < 1 || mes > 12) throw new IllegalArgumentException("El mes debe estar entre 1 y 12");
        if (acumuladoMedio < 0) throw new IllegalArgumentException("El acumulado medio no puede ser negativo");
        this.mes = mes;
        this.acumuladoMedio = acumuladoMedio;
    }

    /** @return mes (1 a 12) */
    public int getMes() { return mes; }
    /** @return acumulado medio en mm */
    public double getAcumuladoMedio() { return acumuladoMedio; }
}
