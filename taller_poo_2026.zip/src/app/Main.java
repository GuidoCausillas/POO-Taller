package app;

import servicio.DatosPrueba;
import servicio.SistemaMeteorologico;

/**
 * Punto de entrada del sistema de alerta temprana. Con el argumento {@code --vacio} arranca
 * sin datos de prueba precargados.
 */
public class Main {
    /**
     * @param args {@code --vacio} para no precargar datos de prueba
     */
    public static void main(String[] args) {
        SistemaMeteorologico sistema = new SistemaMeteorologico();
        boolean vacio = args.length > 0 && args[0].equals("--vacio");
        if (!vacio) {
            DatosPrueba.cargar(sistema);
            System.out.println("(Datos de prueba precargados)");
        }
        new Consola(sistema).ejecutar();
    }
}
