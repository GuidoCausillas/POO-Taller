package app;

import excepciones.MeteorologiaException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.function.Function;
import modelo.*;
import servicio.ServicioReportes;
import servicio.SistemaMeteorologico;

/**
 * Interfaz de usuario por consola: menús para infraestructura, personal, lecturas,
 * alertas y reportes.
 */
public class Consola {
    private static final DateTimeFormatter FH = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private final SistemaMeteorologico sistema;
    private final ServicioReportes reportes;
    private final Scanner in = new Scanner(System.in);

    /**
     * @param sistema sistema sobre el que opera la interfaz
     */
    public Consola(SistemaMeteorologico sistema) {
        this.sistema = sistema;
        this.reportes = new ServicioReportes(sistema);
    }

    /** Ejecuta el menú principal hasta que el usuario elige salir. */
    public void ejecutar() {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n===== SISTEMA DE ALERTA TEMPRANA - EL NIÑO =====");
            System.out.println("1) Infraestructura meteorológica");
            System.out.println("2) Personal técnico");
            System.out.println("3) Registrar lectura de precipitación");
            System.out.println("4) Alertas");
            System.out.println("5) Informes y reportes");
            System.out.println("0) Salir");
            try {
                switch (leerEntero("Opción", 0, 5)) {
                    case 1 -> menuInfraestructura();
                    case 2 -> menuPersonal();
                    case 3 -> registrarLectura();
                    case 4 -> menuAlertas();
                    case 5 -> menuReportes();
                    default -> salir = true;
                }
            } catch (NoSuchElementException e) {
                salir = true; // fin de la entrada
            } catch (MeteorologiaException | RuntimeException e) {
                System.out.println("⚠ " + e.getMessage());
            }
        }
        System.out.println("Hasta luego.");
    }

    // ------------------------------------------------------------------ Menús

    private void menuInfraestructura() throws MeteorologiaException {
        System.out.println("\n-- Infraestructura --");
        System.out.println("1) Listar zonas, estaciones y sensores");
        System.out.println("2) Registrar zona");
        System.out.println("3) Registrar estación");
        System.out.println("4) Registrar sensor");
        System.out.println("5) Instalar sensor en estación");
        System.out.println("6) Retirar sensor de estación");
        System.out.println("7) Cambiar estado de estación");
        System.out.println("8) Cambiar estado de sensor");
        System.out.println("9) Registrar mantenimiento / calibración");
        System.out.println("0) Volver");
        switch (leerEntero("Opción", 0, 9)) {
            case 1 -> {
                sistema.getZonas().forEach(z -> {
                    System.out.println(z);
                    z.getEstaciones().forEach(e -> {
                        System.out.println("   " + e);
                        e.getSensores().forEach(s -> System.out.println("      " + s));
                    });
                });
                System.out.println("Sensores sin instalar:");
                sistema.getSensores().stream().filter(s -> s.getEstacion() == null)
                        .forEach(s -> System.out.println("   " + s));
            }
            case 2 -> {
                String nombre = leerTexto("Nombre de la zona");
                NivelVulnerabilidad v = elegir("Vulnerabilidad", Arrays.asList(NivelVulnerabilidad.values()), Enum::toString);
                double a = leerDouble("Umbral amarilla (mm/24h)");
                double n = leerDouble("Umbral naranja (mm/24h)");
                double r = leerDouble("Umbral roja (mm/24h)");
                System.out.println("Creada: " + sistema.registrarZona(nombre, v, a, n, r));
            }
            case 3 -> {
                String nombre = leerTexto("Nombre de la estación");
                double lat = leerDouble("Latitud");
                double lon = leerDouble("Longitud");
                double alt = leerDouble("Altitud (m)");
                TipoEstacion t = elegir("Tipo", Arrays.asList(TipoEstacion.values()), Enum::toString);
                ZonaGeografica z = elegir("Zona", sistema.getZonas(), ZonaGeografica::toString);
                ResponsableTecnico r = elegir("Responsable técnico", sistema.getResponsables(), ResponsableTecnico::toString);
                System.out.println("Creada: " + sistema.registrarEstacion(nombre, lat, lon, alt, t, z, r));
            }
            case 4 -> {
                String marca = leerTexto("Marca");
                String modelo = leerTexto("Modelo");
                double prec = leerDouble("Precisión (mm)");
                LocalDate cal = leerFecha("Fecha de última calibración (yyyy-MM-dd)");
                System.out.println("Creado: " + sistema.registrarSensor(marca, modelo, prec, cal));
            }
            case 5 -> {
                Sensor s = elegir("Sensor", sistema.getSensores(), Sensor::toString);
                EstacionMeteorologica e = elegir("Estación destino", sistema.getEstaciones(), EstacionMeteorologica::toString);
                e.instalarSensor(s);
                System.out.println("Sensor instalado.");
            }
            case 6 -> {
                EstacionMeteorologica e = elegir("Estación", sistema.getEstaciones(), EstacionMeteorologica::toString);
                Sensor s = elegir("Sensor a retirar", e.getSensores(), Sensor::toString);
                e.retirarSensor(s);
                System.out.println("Sensor retirado; queda disponible para otra estación.");
            }
            case 7 -> {
                EstacionMeteorologica e = elegir("Estación", sistema.getEstaciones(), EstacionMeteorologica::toString);
                e.setEstado(elegir("Nuevo estado", Arrays.asList(EstadoOperativo.values()), Enum::toString));
                System.out.println("Actualizada: " + e);
            }
            case 8 -> {
                Sensor s = elegir("Sensor", sistema.getSensores(), Sensor::toString);
                s.setEstado(elegir("Nuevo estado", Arrays.asList(EstadoOperativo.values()), Enum::toString));
                System.out.println("Actualizado: " + s);
            }
            case 9 -> {
                EstacionMeteorologica e = elegir("Estación", sistema.getEstaciones(), EstacionMeteorologica::toString);
                Sensor s = null;
                if (!e.getSensores().isEmpty() && leerEntero("¿Aplica a un sensor? (1=sí, 0=no)", 0, 1) == 1) {
                    s = elegir("Sensor", e.getSensores(), Sensor::toString);
                }
                ResponsableTecnico r = elegir("Técnico que lo realiza", sistema.getResponsables(), ResponsableTecnico::toString);
                TipoMantenimiento t = elegir("Tipo", Arrays.asList(TipoMantenimiento.values()), Enum::toString);
                LocalDate f = leerFecha("Fecha (yyyy-MM-dd)");
                String d = leerTexto("Descripción");
                System.out.println("Registrado: " + sistema.registrarMantenimiento(e, s, r, t, f, d));
            }
            default -> { }
        }
    }

    private void menuPersonal() throws MeteorologiaException {
        System.out.println("\n-- Personal técnico --");
        System.out.println("1) Listar responsables y equipos");
        System.out.println("2) Registrar responsable técnico");
        System.out.println("3) Crear equipo de respuesta");
        System.out.println("4) Agregar técnico a un equipo");
        System.out.println("0) Volver");
        switch (leerEntero("Opción", 0, 4)) {
            case 1 -> {
                System.out.println("Responsables:");
                sistema.getResponsables().forEach(r -> System.out.println("   " + r
                        + (r.getEquipo() != null ? " [equipo: " + r.getEquipo().getNombreEquipo() + "]" : "")));
                System.out.println("Equipos:");
                sistema.getEquipos().forEach(e -> {
                    System.out.println("   " + e);
                    e.getIntegrantes().forEach(r -> System.out.println("       - " + r));
                });
            }
            case 2 -> {
                String dni = leerTexto("DNI");
                String nom = leerTexto("Nombre");
                String ape = leerTexto("Apellido");
                String mail = leerTexto("Correo electrónico");
                String cel = leerTexto("Celular");
                String esp = leerTexto("Especialidad");
                String lic = leerTexto("Número de licencia");
                System.out.println("Registrado: " + sistema.registrarResponsable(dni, nom, ape, mail, cel, esp, lic));
            }
            case 3 -> System.out.println("Creado: " + sistema.crearEquipo(leerTexto("Nombre del equipo")));
            case 4 -> {
                EquipoRespuesta e = elegir("Equipo", sistema.getEquipos(), EquipoRespuesta::toString);
                ResponsableTecnico r = elegir("Técnico", sistema.getResponsables(), ResponsableTecnico::toString);
                e.agregarIntegrante(r);
                System.out.println("Técnico incorporado: " + e);
            }
            default -> { }
        }
    }

    private void registrarLectura() throws MeteorologiaException {
        System.out.println("\n-- Registrar lectura --");
        Sensor s = elegir("Sensor", sistema.getSensores(), Sensor::toString);
        double mm = leerDouble("Milímetros (0 a 500)");
        LocalDateTime fh = leerFechaHora("Fecha y hora (yyyy-MM-dd HH:mm)");
        SistemaMeteorologico.ResultadoLectura r = sistema.registrarLectura(s, mm, fh);
        System.out.println("Lectura registrada: " + r.medicion());
        if (r.alerta() != null) {
            System.out.println("🔔 ALERTA EMITIDA: " + r.alerta());
            if (r.alerta().estaPendienteDeEquipo()) {
                System.out.println("   ⚠ No hay equipos conformados: la alerta queda pendiente de asignación.");
            }
        }
    }

    private void menuAlertas() throws MeteorologiaException {
        System.out.println("\n-- Alertas --");
        System.out.println("1) Ver nivel vigente por zona");
        System.out.println("2) Registrar alerta de operador (crecida / tormenta)");
        System.out.println("3) Asignar equipo a alerta pendiente");
        System.out.println("4) Marcar alerta como atendida");
        System.out.println("0) Volver");
        switch (leerEntero("Opción", 0, 4)) {
            case 1 -> sistema.getZonas().forEach(z -> System.out.println(z));
            case 2 -> {
                ZonaGeografica z = elegir("Zona", sistema.getZonas(), ZonaGeografica::toString);
                TipoEventoClimatico ev = elegir("Evento", List.of(TipoEventoClimatico.CRECIDA_RIO,
                        TipoEventoClimatico.TORMENTA_SEVERA), TipoEventoClimatico::toString);
                NivelAlerta n = elegir("Nivel", Arrays.asList(NivelAlerta.values()), NivelAlerta::toString);
                String desc = leerTexto("Descripción");
                EquipoRespuesta eq = null;
                if (n.requiereEquipo()) eq = elegir("Equipo de respuesta (obligatorio)", sistema.getEquipos(), EquipoRespuesta::toString);
                System.out.println("Registrada: " + sistema.registrarAlertaOperador(z, ev, n, desc, eq, LocalDateTime.now()));
            }
            case 3 -> {
                List<Alerta> pend = sistema.getAlertas().stream().filter(Alerta::estaPendienteDeEquipo).toList();
                Alerta a = elegir("Alerta pendiente", pend, Alerta::toString);
                sistema.asignarEquipo(a, elegir("Equipo", sistema.getEquipos(), EquipoRespuesta::toString));
                System.out.println("Asignada: " + a);
            }
            case 4 -> {
                List<Alerta> ab = sistema.getAlertas().stream().filter(a -> !a.isAtendida()).toList();
                Alerta a = elegir("Alerta abierta", ab, Alerta::toString);
                a.marcarAtendida();
                System.out.println("Atendida: " + a);
            }
            default -> { }
        }
    }

    private void menuReportes() {
        System.out.println("\n-- Informes y reportes --");
        System.out.println("1) Histórico de precipitaciones por estación");
        System.out.println("2) Histórico de precipitaciones por zona");
        System.out.println("3) Ranking de estaciones por volumetría");
        System.out.println("4) Historial de alertas (con filtros)");
        System.out.println("5) Ficha técnica operativa de una estación");
        System.out.println("6) Informe de fallas y mantenimiento");
        System.out.println("7) Anomalía climática de una zona");
        System.out.println("0) Volver");
        switch (leerEntero("Opción", 0, 7)) {
            case 1 -> System.out.println(reportes.historico(
                    elegir("Estación", sistema.getEstaciones(), EstacionMeteorologica::toString)));
            case 2 -> System.out.println(reportes.historico(
                    elegir("Zona", sistema.getZonas(), ZonaGeografica::toString)));
            case 3 -> {
                LocalDate d = leerFecha("Desde (yyyy-MM-dd)");
                LocalDate h = leerFecha("Hasta (yyyy-MM-dd)");
                System.out.println(reportes.rankingEstaciones(d, h));
            }
            case 4 -> {
                NivelAlerta n = elegirOpcional("Nivel", Arrays.asList(NivelAlerta.values()), NivelAlerta::toString);
                ZonaGeografica z = elegirOpcional("Zona", sistema.getZonas(), ZonaGeografica::toString);
                LocalDate d = leerFechaOpcional("Desde (yyyy-MM-dd, vacío = sin límite)");
                LocalDate h = leerFechaOpcional("Hasta (yyyy-MM-dd, vacío = sin límite)");
                System.out.println(reportes.historialAlertas(n, d, h, z));
            }
            case 5 -> System.out.println(reportes.fichaTecnica(
                    elegir("Estación", sistema.getEstaciones(), EstacionMeteorologica::toString)));
            case 6 -> System.out.println(reportes.informeFallas());
            case 7 -> System.out.println(reportes.anomaliaClimatica(
                    elegir("Zona", sistema.getZonas(), ZonaGeografica::toString)));
            default -> { }
        }
    }

    // ------------------------------------------------------------------ Entrada de datos

    private <T> T elegir(String titulo, List<T> items, Function<T, String> etiqueta) {
        if (items.isEmpty()) throw new IllegalStateException("No hay elementos disponibles para: " + titulo);
        System.out.println(titulo + ":");
        for (int i = 0; i < items.size(); i++) System.out.printf("  %d) %s%n", i + 1, etiqueta.apply(items.get(i)));
        return items.get(leerEntero("Elegir", 1, items.size()) - 1);
    }

    private <T> T elegirOpcional(String titulo, List<T> items, Function<T, String> etiqueta) {
        System.out.println(titulo + " (0 = todos):");
        for (int i = 0; i < items.size(); i++) System.out.printf("  %d) %s%n", i + 1, etiqueta.apply(items.get(i)));
        int n = leerEntero("Elegir", 0, items.size());
        return n == 0 ? null : items.get(n - 1);
    }

    private String leerTexto(String msg) {
        System.out.print(msg + ": ");
        return in.nextLine().trim();
    }

    private int leerEntero(String msg, int min, int max) {
        while (true) {
            try {
                int n = Integer.parseInt(leerTexto(msg));
                if (n >= min && n <= max) return n;
            } catch (NumberFormatException ignored) { }
            System.out.println("  Ingrese un número entre " + min + " y " + max);
        }
    }

    private double leerDouble(String msg) {
        while (true) {
            try {
                return Double.parseDouble(leerTexto(msg).replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.println("  Ingrese un número válido");
            }
        }
    }

    private LocalDate leerFecha(String msg) {
        while (true) {
            try {
                return LocalDate.parse(leerTexto(msg));
            } catch (DateTimeParseException e) {
                System.out.println("  Formato inválido (use yyyy-MM-dd)");
            }
        }
    }

    private LocalDate leerFechaOpcional(String msg) {
        while (true) {
            String t = leerTexto(msg);
            if (t.isEmpty()) return null;
            try {
                return LocalDate.parse(t);
            } catch (DateTimeParseException e) {
                System.out.println("  Formato inválido (use yyyy-MM-dd)");
            }
        }
    }

    private LocalDateTime leerFechaHora(String msg) {
        while (true) {
            try {
                return LocalDateTime.parse(leerTexto(msg), FH);
            } catch (DateTimeParseException e) {
                System.out.println("  Formato inválido (use yyyy-MM-dd HH:mm)");
            }
        }
    }
}
