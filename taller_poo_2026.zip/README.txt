Taller POO 2026 - Sistema de alerta temprana (El Niño)
Requisitos: Java 17 o superior. Sin dependencias externas.

Compilar:
  Linux/Mac: javac -encoding UTF-8 -d out $(find src -name '*.java')
  Windows  : dir /s /b src\*.java > fuentes.txt  &&  javac -encoding UTF-8 -d out @fuentes.txt
Ejecutar (con datos de prueba):  java -Dfile.encoding=UTF-8 -cp out app.Main
Ejecutar sin datos:               java -cp out app.Main --vacio
(En Windows, si se ven mal los acentos: chcp 65001)
JavaDoc: abrir docs/index.html
